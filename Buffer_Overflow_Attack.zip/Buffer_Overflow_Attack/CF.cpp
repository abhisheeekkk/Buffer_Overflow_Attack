/*
Task : Using Techniques of Buffer Overflow Attack this 
program can get you admin access even if you have given 
a wrong password to the system.

In first test case I will write a correct password and 
will get the user access and in the next test case I 
will write wrong password but still get the admin access.

*/

#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <cstring>
#include <bits/stdc++.h>
typedef long long int lld;
 
using namespace std;
 
int main()
{
    char pass[10];
    bool password = 0;
    
    cout<<"Enter your Password: "<<endl;
    gets(pass);

    if(strcmp(pass, "JaiHind"))
    {
        cout<<"Wrong Password"<<endl;
    }

    else
    {
        cout<<"Your Password is correct"<<endl;
        password = 1;
    }
    
    if(password)
    {
        cout<<"Admin rights given to the user.";
    }
    return 0;
}


