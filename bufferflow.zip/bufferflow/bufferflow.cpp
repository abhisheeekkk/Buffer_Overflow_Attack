#include <iostream>
using namespace std;
int main(void)
{
  int arr[10];
  int arr_num;
  int num,i;

  for (i = 0; i < 12; i++)
  {
    arr_num = 5;
    arr[i]= arr_num;
    cout<<arr[i]<<endl;
  }
  return 0;
}